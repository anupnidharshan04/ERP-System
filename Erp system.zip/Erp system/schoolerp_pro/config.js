// Supabase configuration 
window.SUPABASE_URL = "https://jwkzyvqotfpfyshxirbe.supabase.co";
window.SUPABASE_ANON_KEY = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Imp3a3p5dnFvdGZwZnlzaHhpcmJlIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NTYxOTY4MjIsImV4cCI6MjA3MTc3MjgyMn0.Drs-sfTDTAYWb5dSy8pl4OzElWQnzyfW-IMAokEUu_c";
